-- drop_dev_database.sql
DROP DATABASE IF EXISTS hbnb_dev_db;

-- drop_dev_database.sql
DROP DATABASE IF EXISTS hbnb_test_db;
