-- db_list_users.sql
USE your_database_name;
SELECT * FROM users;
