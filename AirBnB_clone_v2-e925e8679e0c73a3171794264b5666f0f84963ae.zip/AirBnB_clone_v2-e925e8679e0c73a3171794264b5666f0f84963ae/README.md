A multiple bit by bit project to create AirBnB clone.

1st part a console
